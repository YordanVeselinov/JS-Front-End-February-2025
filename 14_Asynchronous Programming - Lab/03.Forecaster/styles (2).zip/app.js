function attachEvents() {
    // Use 'let' instead of 'const'
    let locationInput = document.getElementById('location');
    let submitButton = document.getElementById('submit');
    let forecastDiv = document.getElementById('forecast'); // Main forecast container
    let currentDiv = document.getElementById('current');
    let upcomingDiv = document.getElementById('upcoming');

    // Keep the labels handy for resetting
    let currentLabelHtml = '<div class="label">Current conditions</div>';
    let upcomingLabelHtml = '<div class="label">Three-day forecast</div>';

    let baseUrl = 'http://localhost:3030/jsonstore/forecaster/';

    // Use 'let' for the symbols object
    let weatherSymbols = {
        'Sunny': '&#x2600;',         // ☀
        'Partly sunny': '&#x26C5;',   // ⛅
        'Overcast': '&#x2601;',       // ☁
        'Rain': '&#x2614;',           // ☂
        'Degrees': '&#176;'          // °
    };

    submitButton.addEventListener('click', getWeather);

    async function getWeather() {
        // Use 'let' for locationName
        let locationName = locationInput.value.trim();

        // --- Handle Invalid Input: If empty or whitespace, do nothing ---
        if (!locationName) {
            return; // Stop execution here, don't fetch, don't show errors
        }

        // --- Reset UI state BEFORE fetching (only if input is valid) ---
        forecastDiv.style.display = 'none'; // Hide forecast initially
        // Reset content to just the labels, ensuring structure is correct
        currentDiv.innerHTML = currentLabelHtml;
        upcomingDiv.innerHTML = upcomingLabelHtml;


        try {
            // 1. Get Location Code (use 'let')
            let locationsResponse = await fetch(baseUrl + 'locations');
            if (!locationsResponse.ok) {
                throw new Error(`Locations request failed: ${locationsResponse.status} ${locationsResponse.statusText || ''}`);
            }
            let locations;
            try {
                 locations = await locationsResponse.json();
            } catch (jsonError) {
                 throw new Error("Invalid data received for locations.");
            }

            // Use 'let'
            let location = locations.find(loc => loc.name.toLowerCase() === locationName.toLowerCase());
            if (!location) {
                throw new Error(`Location "${locationName}" not found.`);
            }
            // Use 'let'
            let locationCode = location.code;

            // 2. Get Forecasts (use 'let')
            let [todayResponse, upcomingResponse] = await Promise.all([
                fetch(`${baseUrl}today/${locationCode}`),
                fetch(`${baseUrl}upcoming/${locationCode}`)
            ]);

            if (!todayResponse.ok) {
                 throw new Error(`Today's forecast request failed: ${todayResponse.status} ${todayResponse.statusText || ''}`);
            }
            if (!upcomingResponse.ok) {
                 throw new Error(`Upcoming forecast request failed: ${upcomingResponse.status} ${upcomingResponse.statusText || ''}`);
            }

            // Use 'let'
            let todayData, upcomingData;
             try {
                 todayData = await todayResponse.json();
                 upcomingData = await upcomingResponse.json();
             } catch (jsonError) {
                 throw new Error("Invalid data received for forecast.");
             }

            // 3. Display Forecast (if successful)
            displayForecast(todayData, upcomingData);

        } catch (error) {
            console.error("Error during weather fetch:", error); // Log for debugging
            // Display the error within the UI structure
            displayError(error.message || "An unknown error occurred.");
        }
    }

    function displayForecast(todayData, upcomingData) {
        // Reset again just to be safe
        currentDiv.innerHTML = currentLabelHtml;
        upcomingDiv.innerHTML = upcomingLabelHtml;

        // --- Validate and Display Current Conditions --- (use 'let')
        let currentForecast = todayData.forecast;
        if (!currentForecast || typeof currentForecast !== 'object') {
             displayError("Invalid current forecast data format.");
             return;
        }

        // Use 'let' for elements
        let currentForecastsDiv = document.createElement('div');
        currentForecastsDiv.className = 'forecasts';

        let conditionSymbolSpan = document.createElement('span');
        conditionSymbolSpan.className = 'condition symbol';
        conditionSymbolSpan.innerHTML = weatherSymbols[currentForecast.condition] || '?';

        let conditionInfoSpan = document.createElement('span');
        conditionInfoSpan.className = 'condition';

        let locationSpan = document.createElement('span');
        locationSpan.className = 'forecast-data';
        locationSpan.textContent = todayData.name || 'Unknown Location';

        let tempSpan = document.createElement('span');
        tempSpan.className = 'forecast-data';
        let lowTemp = currentForecast.low ?? 'N/A';
        let highTemp = currentForecast.high ?? 'N/A';
        tempSpan.innerHTML = `${lowTemp}${weatherSymbols.Degrees}/${highTemp}${weatherSymbols.Degrees}`;

        let conditionTextSpan = document.createElement('span');
        conditionTextSpan.className = 'forecast-data';
        conditionTextSpan.textContent = currentForecast.condition || 'N/A';

        conditionInfoSpan.appendChild(locationSpan);
        conditionInfoSpan.appendChild(tempSpan);
        conditionInfoSpan.appendChild(conditionTextSpan);

        currentForecastsDiv.appendChild(conditionSymbolSpan);
        currentForecastsDiv.appendChild(conditionInfoSpan);
        currentDiv.appendChild(currentForecastsDiv);


        // --- Validate and Display Upcoming Forecast --- (use 'let')
         if (!upcomingData.forecast || !Array.isArray(upcomingData.forecast)) {
             displayError("Invalid upcoming forecast data format.");
             return;
         }

        let upcomingForecastInfoDiv = document.createElement('div');
        upcomingForecastInfoDiv.className = 'forecast-info';

        upcomingData.forecast.forEach(day => {
            if (!day || typeof day !== 'object') return;

            // Use 'let' for elements inside loop
            let upcomingSpan = document.createElement('span');
            upcomingSpan.className = 'upcoming';

            let symbolSpan = document.createElement('span');
            symbolSpan.className = 'symbol';
            symbolSpan.innerHTML = weatherSymbols[day.condition] || '?';

            let tempSpan = document.createElement('span');
            tempSpan.className = 'forecast-data';
            let dayLowTemp = day.low ?? 'N/A';
            let dayHighTemp = day.high ?? 'N/A';
            tempSpan.innerHTML = `${dayLowTemp}${weatherSymbols.Degrees}/${dayHighTemp}${weatherSymbols.Degrees}`;

            let conditionSpan = document.createElement('span');
            conditionSpan.className = 'forecast-data';
            conditionSpan.textContent = day.condition || 'N/A';

            upcomingSpan.appendChild(symbolSpan);
            upcomingSpan.appendChild(tempSpan);
            upcomingSpan.appendChild(conditionSpan);
            upcomingForecastInfoDiv.appendChild(upcomingSpan);
        });

        upcomingDiv.appendChild(upcomingForecastInfoDiv);

        // --- Make forecast visible ---
        forecastDiv.style.display = 'block';
    }

    function displayError(message) {
        // Ensure the base structure is present
        currentDiv.innerHTML = currentLabelHtml;
        upcomingDiv.innerHTML = upcomingLabelHtml;

        // Create the error message element (use 'let')
        let errorMsgElement = document.createElement('div');
        errorMsgElement.textContent = `Error: ${message}`;
        errorMsgElement.style.textAlign = 'center';
        errorMsgElement.style.padding = '1em 0';
        errorMsgElement.style.fontWeight = 'bold';
        errorMsgElement.style.color = 'red';

        currentDiv.appendChild(errorMsgElement);

        // Make the forecast div visible to show the error message
        forecastDiv.style.display = 'block';
    }
}

attachEvents();