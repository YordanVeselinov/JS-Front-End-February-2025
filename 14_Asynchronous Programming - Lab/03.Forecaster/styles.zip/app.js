function attachEvents() {
    const locationInput = document.getElementById('location');
    const submitButton = document.getElementById('submit');
    const forecastDiv = document.getElementById('forecast'); // Main forecast container
    const currentDiv = document.getElementById('current');
    const upcomingDiv = document.getElementById('upcoming');

    // Keep the labels handy for resetting
    const currentLabelHtml = '<div class="label">Current conditions</div>';
    const upcomingLabelHtml = '<div class="label">Three-day forecast</div>';

    const baseUrl = 'http://localhost:3030/jsonstore/forecaster/';

    const weatherSymbols = {
        'Sunny': '&#x2600;',         // ☀
        'Partly sunny': '&#x26C5;',   // ⛅
        'Overcast': '&#x2601;',       // ☁
        'Rain': '&#x2614;',           // ☂
        'Degrees': '&#176;'          // °
    };

    submitButton.addEventListener('click', getWeather);

    async function getWeather() {
        // --- Reset UI state BEFORE fetching ---
        forecastDiv.style.display = 'none'; // Hide forecast initially
        // Reset content to just the labels, ensuring structure is correct
        currentDiv.innerHTML = currentLabelHtml;
        upcomingDiv.innerHTML = upcomingLabelHtml;

        const locationName = locationInput.value.trim();
        if (!locationName) {
            // Optionally handle empty input, maybe show a message in #current
            // displayError("Please enter a location."); // Example if needed
            return;
        }

        try {
            // 1. Get Location Code
            const locationsResponse = await fetch(baseUrl + 'locations');
            if (!locationsResponse.ok) {
                throw new Error(`Locations request failed: ${locationsResponse.status} ${locationsResponse.statusText || ''}`);
            }
            let locations;
            try {
                 locations = await locationsResponse.json();
            } catch (jsonError) {
                 throw new Error("Invalid data received for locations.");
            }

            const location = locations.find(loc => loc.name.toLowerCase() === locationName.toLowerCase());
            if (!location) {
                throw new Error(`Location "${locationName}" not found.`);
            }
            const locationCode = location.code;

            // 2. Get Forecasts
            const [todayResponse, upcomingResponse] = await Promise.all([
                fetch(`${baseUrl}today/${locationCode}`),
                fetch(`${baseUrl}upcoming/${locationCode}`)
            ]);

            if (!todayResponse.ok) {
                 throw new Error(`Today's forecast request failed: ${todayResponse.status} ${todayResponse.statusText || ''}`);
            }
            if (!upcomingResponse.ok) {
                 throw new Error(`Upcoming forecast request failed: ${upcomingResponse.status} ${upcomingResponse.statusText || ''}`);
            }

            let todayData, upcomingData;
             try {
                 todayData = await todayResponse.json();
                 upcomingData = await upcomingResponse.json();
             } catch (jsonError) {
                 throw new Error("Invalid data received for forecast.");
             }

            // 3. Display Forecast (if successful)
            displayForecast(todayData, upcomingData);

        } catch (error) {
            console.error("Error during weather fetch:", error); // Log for debugging
            // Display the error within the UI structure
            displayError(error.message || "An unknown error occurred.");
        }
    }

    function displayForecast(todayData, upcomingData) {
        // Reset again just to be safe (getWeather should have done it)
        currentDiv.innerHTML = currentLabelHtml;
        upcomingDiv.innerHTML = upcomingLabelHtml;

        // --- Validate and Display Current Conditions ---
        const currentForecast = todayData.forecast;
        if (!currentForecast || typeof currentForecast !== 'object') {
             displayError("Invalid current forecast data format."); // This will show error and stop
             return;
        }

        const currentForecastsDiv = document.createElement('div');
        currentForecastsDiv.className = 'forecasts';

        const conditionSymbolSpan = document.createElement('span');
        conditionSymbolSpan.className = 'condition symbol';
        conditionSymbolSpan.innerHTML = weatherSymbols[currentForecast.condition] || '?';

        const conditionInfoSpan = document.createElement('span');
        conditionInfoSpan.className = 'condition';

        const locationSpan = document.createElement('span');
        locationSpan.className = 'forecast-data';
        locationSpan.textContent = todayData.name || 'Unknown Location';

        const tempSpan = document.createElement('span');
        tempSpan.className = 'forecast-data';
        const lowTemp = currentForecast.low ?? 'N/A';
        const highTemp = currentForecast.high ?? 'N/A';
        tempSpan.innerHTML = `${lowTemp}${weatherSymbols.Degrees}/${highTemp}${weatherSymbols.Degrees}`;

        const conditionTextSpan = document.createElement('span');
        conditionTextSpan.className = 'forecast-data';
        conditionTextSpan.textContent = currentForecast.condition || 'N/A';

        conditionInfoSpan.appendChild(locationSpan);
        conditionInfoSpan.appendChild(tempSpan);
        conditionInfoSpan.appendChild(conditionTextSpan);

        currentForecastsDiv.appendChild(conditionSymbolSpan);
        currentForecastsDiv.appendChild(conditionInfoSpan);
        // Append forecast data AFTER the label within currentDiv
        currentDiv.appendChild(currentForecastsDiv);


        // --- Validate and Display Upcoming Forecast ---
         if (!upcomingData.forecast || !Array.isArray(upcomingData.forecast)) {
             // Display an error but potentially keep the current forecast visible?
             // For simplicity matching requirements, let's show a general error instead.
             displayError("Invalid upcoming forecast data format.");
             return; // Stop execution for this function
         }

        const upcomingForecastInfoDiv = document.createElement('div');
        upcomingForecastInfoDiv.className = 'forecast-info';

        upcomingData.forecast.forEach(day => {
            // Basic validation for each day object
            if (!day || typeof day !== 'object') return; // Skip invalid day entries

            const upcomingSpan = document.createElement('span');
            upcomingSpan.className = 'upcoming';

            const symbolSpan = document.createElement('span');
            symbolSpan.className = 'symbol';
            symbolSpan.innerHTML = weatherSymbols[day.condition] || '?';

            const tempSpan = document.createElement('span');
            tempSpan.className = 'forecast-data';
            const dayLowTemp = day.low ?? 'N/A';
            const dayHighTemp = day.high ?? 'N/A';
            tempSpan.innerHTML = `${dayLowTemp}${weatherSymbols.Degrees}/${dayHighTemp}${weatherSymbols.Degrees}`;

            const conditionSpan = document.createElement('span');
            conditionSpan.className = 'forecast-data';
            conditionSpan.textContent = day.condition || 'N/A';

            upcomingSpan.appendChild(symbolSpan);
            upcomingSpan.appendChild(tempSpan);
            upcomingSpan.appendChild(conditionSpan);
            upcomingForecastInfoDiv.appendChild(upcomingSpan);
        });

        // Append forecast data AFTER the label within upcomingDiv
        upcomingDiv.appendChild(upcomingForecastInfoDiv);

        // --- Make forecast visible ---
        forecastDiv.style.display = 'block'; // Show the whole forecast section
    }

    function displayError(message) {
        // Ensure the base structure is present
        currentDiv.innerHTML = currentLabelHtml;
        upcomingDiv.innerHTML = upcomingLabelHtml;

        // Create the error message element
        const errorMsgElement = document.createElement('div');
        errorMsgElement.textContent = `Error: ${message}`;
        errorMsgElement.style.textAlign = 'center';
        errorMsgElement.style.padding = '1em 0'; // Add some padding
        errorMsgElement.style.fontWeight = 'bold';
        errorMsgElement.style.color = 'red'; // Make it stand out

        // Append the error message after the label in the 'current' section
        currentDiv.appendChild(errorMsgElement);

        // Make the forecast div visible to show the error message
        forecastDiv.style.display = 'block';
    }
}

attachEvents();