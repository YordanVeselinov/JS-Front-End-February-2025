async function solution() {
    let mainSection = document.getElementById('main');
    let listUrl = 'http://localhost:3030/jsonstore/advanced/articles/list';
    let detailsBaseUrl = 'http://localhost:3030/jsonstore/advanced/articles/details/';

    mainSection.innerHTML = ''; // Clear any static content or previous loads

    try {
        // Fetch the list of articles
        let listResponse = await fetch(listUrl);
        if (!listResponse.ok) {
            throw new Error(`Error fetching article list: ${listResponse.status}`);
        }
        let articlesArray = await listResponse.json(); // Assumes array based on tests

        // Create and append an accordion item for each article
        articlesArray.forEach(article => {
            let accordionDiv = createAccordionItem(article);
            mainSection.appendChild(accordionDiv);
        });

    } catch (error) {
        console.error("Failed to load articles:", error);
        mainSection.textContent = `Error: ${error.message}`; // Display error
    }

    function createAccordionItem(article) {
        // Main container
        let divAccordion = document.createElement('div');
        divAccordion.className = 'accordion';

        // Head section (title + button)
        let divHead = document.createElement('div');
        divHead.className = 'head';

        let spanTitle = document.createElement('span');
        spanTitle.textContent = article.title;

        let buttonToggle = document.createElement('button');
        buttonToggle.className = 'button';
        buttonToggle.id = article._id; // Use article ID for the button ID
        buttonToggle.textContent = 'More';
        buttonToggle.addEventListener('click', toggleDetailsHandler);

        divHead.appendChild(spanTitle);
        divHead.appendChild(buttonToggle);

        // Extra section (hidden content)
        let divExtra = document.createElement('div');
        divExtra.className = 'extra';
        divExtra.style.display = 'none'; // Initially hidden

        let pContent = document.createElement('p');
        // Content will be added later on fetch
        divExtra.appendChild(pContent);

        // Assemble accordion item
        divAccordion.appendChild(divHead);
        divAccordion.appendChild(divExtra);

        return divAccordion;
    }

    async function toggleDetailsHandler(event) {
        let button = event.target;
        let articleId = button.id;
        let accordionDiv = button.closest('.accordion'); // Find the parent accordion div
        let extraDiv = accordionDiv.querySelector('.extra');
        let contentP = extraDiv.querySelector('p');

        if (!extraDiv || !contentP) {
            console.error('Could not find content elements for article:', articleId);
            return;
        }

        // Check current state by button text
        let isHidden = button.textContent === 'More';

        if (isHidden) {
            // --- Fetch content if showing for the first time (or always fetch) ---
            // Optimization: Check if contentP already has content; if so, just show.
            // Let's always fetch for simplicity and to ensure latest content, as per requirement.
            
            try {
                button.disabled = true; // Prevent rapid clicks while fetching
                button.textContent = 'Loading...';

                let detailsUrl = `${detailsBaseUrl}${articleId}`;
                let detailsResponse = await fetch(detailsUrl);
                if (!detailsResponse.ok) {
                    throw new Error(`Error fetching details for ${articleId}: ${detailsResponse.status}`);
                }
                let detailsData = await detailsResponse.json();

                contentP.textContent = detailsData.content; // Populate content
                
                // Show section and change button text
                extraDiv.style.display = 'block';
                button.textContent = 'Less';

            } catch (error) {
                console.error("Failed to load article details:", error);
                contentP.textContent = `Error: ${error.message}`; // Show error in content area
                 // Optionally re-enable button and reset text even on error
                button.textContent = 'More'; // Reset button text on error
                extraDiv.style.display = 'none'; // Keep hidden on error
            } finally {
                 button.disabled = false; // Re-enable button
            }

        } else { // Button text is 'Less', so hide the content
            extraDiv.style.display = 'none';
            button.textContent = 'More';
            // Optionally clear contentP.textContent = ''; 
        }
    }
}

// Run the main function when the script loads
solution();