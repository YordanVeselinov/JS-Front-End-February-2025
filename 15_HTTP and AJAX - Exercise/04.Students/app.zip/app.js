function attachEvents() {
    // Get references to DOM elements
    let tableBody = document.querySelector('#results tbody');
    let studentForm = document.getElementById('form');
    let notificationP = document.querySelector('.notification'); // Get notification paragraph

    // Base URL for the student collection
    let baseUrl = 'http://localhost:3030/jsonstore/collections/students';

    // Attach event listener to the form's submit event
    studentForm.addEventListener('submit', submitStudentHandler);

    // Initial load of students when the script runs
    loadStudents();

    async function loadStudents() {
        // Clear previous table rows
        tableBody.innerHTML = '';
        // Clear previous notifications
        if (notificationP) notificationP.textContent = '';

        try {
            let response = await fetch(baseUrl);
            if (!response.ok) {
                throw new Error(`HTTP error loading students! status: ${response.status}`);
            }
            let studentsData = await response.json();

            // The response is an object of objects, tests mock an array. 
            // Object.values handles both cases correctly for iteration.
            let studentsArray = Object.values(studentsData);

            // Populate the table
            studentsArray.forEach(student => {
                // Basic validation of received data structure
                if (student.firstName && student.lastName && student.facultyNumber && student.grade !== undefined) {
                    createStudentRow(student);
                }
            });

        } catch (error) {
            console.error("Error loading students:", error);
            displayNotification(`Error: ${error.message}`); // Display error to user
        }
    }

    function createStudentRow(student) {
        let tr = document.createElement('tr');

        let tdFirstName = document.createElement('td');
        tdFirstName.textContent = student.firstName;

        let tdLastName = document.createElement('td');
        tdLastName.textContent = student.lastName;

        let tdFacultyNumber = document.createElement('td');
        tdFacultyNumber.textContent = student.facultyNumber;

        let tdGrade = document.createElement('td');
        // Format grade to 2 decimal places for consistent display
        tdGrade.textContent = Number(student.grade).toFixed(2);

        tr.appendChild(tdFirstName);
        tr.appendChild(tdLastName);
        tr.appendChild(tdFacultyNumber);
        tr.appendChild(tdGrade);

        tableBody.appendChild(tr);
    }

    async function submitStudentHandler(event) {
        event.preventDefault(); // Prevent default form submission

        // Use FormData to easily get all form values
        let formData = new FormData(event.currentTarget); // or studentForm

        let firstName = formData.get('firstName').trim();
        let lastName = formData.get('lastName').trim();
        let facultyNumber = formData.get('facultyNumber').trim();
        let gradeString = formData.get('grade').trim();

        // Validation Checks
        if (!firstName || !lastName || !facultyNumber || !gradeString) {
            displayNotification("Error: All fields are required!");
            return;
        }

        // Check if faculty number contains only digits
        if (!/^\d+$/.test(facultyNumber)) {
            displayNotification("Error: Faculty Number must contain only digits!");
            return;
        }

        // Check if grade is a valid number
        let gradeNumber = Number(gradeString); // Convert grade to number for validation and sending
        if (isNaN(gradeNumber)) {
            displayNotification("Error: Grade must be a valid number!");
            return;
        }

        // Clear previous notification if validation passes
        displayNotification("");

        // Prepare student data object
        let studentData = {
            firstName: firstName,
            lastName: lastName,
            facultyNumber: facultyNumber,
            grade: gradeNumber // Send grade as a number
        };

        try {
            let response = await fetch(baseUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(studentData)
            });

            if (!response.ok) {
                throw new Error(`HTTP error creating student! status: ${response.status}`);
            }

            // Clear the form fields
            event.currentTarget.reset(); // Resets the form that triggered the event

            // Reload the student list to show the new entry
            await loadStudents();

        } catch (error) {
            console.error("Error submitting student:", error);
            displayNotification(`Error: ${error.message}`); // Display error to user
        }
    }

    // Helper function to display notifications
    function displayNotification(message) {
        if (notificationP) {
            notificationP.textContent = message;
        }
    }
}

// Initialize the application logic
attachEvents();