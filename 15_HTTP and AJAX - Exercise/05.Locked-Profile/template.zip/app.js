async function lockedProfile() {
    let mainElement = document.getElementById('main');
    let url = 'http://localhost:3030/jsonstore/advanced/profiles';

    mainElement.innerHTML = ''; // Clear initial content/previous profiles

    try {
        let response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        // Tests mock an array, requirements imply object. Handle array directly.
        let profilesData = await response.json(); 
        let profilesArray = Array.isArray(profilesData) ? profilesData : Object.values(profilesData);


        profilesArray.forEach((profile, index) => {
            // Create profile card using index + 1 for user numbering (matches user1, user2, ...)
            let profileCard = createProfileCard(profile, index + 1); 
            mainElement.appendChild(profileCard);
        });

    } catch (error) {
        console.error("Error loading profiles:", error);
        mainElement.textContent = `Error loading profiles: ${error.message}`; // Display error
    }
}

function createProfileCard(profile, userIndex) {
    // Create main profile container
    let profileDiv = document.createElement('div');
    profileDiv.className = 'profile';

    // --- Replicating HTML structure strictly ---

    // Image
    let img = document.createElement('img');
    img.src = './iconProfile2.png';
    img.className = 'userIcon';
    profileDiv.appendChild(img);

    // Lock label and radio
    let lockLabel = document.createElement('label');
    lockLabel.textContent = 'Lock';
    profileDiv.appendChild(lockLabel);
    let lockRadio = document.createElement('input');
    lockRadio.type = 'radio';
    lockRadio.name = `user${userIndex}Locked`; // Unique name
    lockRadio.value = 'lock';
    lockRadio.checked = true;
    profileDiv.appendChild(lockRadio);

    // Unlock label and radio
    let unlockLabel = document.createElement('label');
    unlockLabel.textContent = 'Unlock';
    profileDiv.appendChild(unlockLabel);
    let unlockRadio = document.createElement('input');
    unlockRadio.type = 'radio';
    unlockRadio.name = `user${userIndex}Locked`; // Same unique name
    unlockRadio.value = 'unlock';
    profileDiv.appendChild(unlockRadio);

    // Separator HR
    profileDiv.appendChild(document.createElement('hr'));

    // Username label and input
    let usernameLabel = document.createElement('label');
    usernameLabel.textContent = 'Username';
    profileDiv.appendChild(usernameLabel);
    let usernameInput = document.createElement('input');
    usernameInput.type = 'text';
    usernameInput.name = `user${userIndex}Username`; // Unique name
    usernameInput.value = profile.username || '';
    usernameInput.disabled = true;
    usernameInput.readOnly = true;
    profileDiv.appendChild(usernameInput);

    // Hidden fields container DIV - **Crucially matches the static HTML structure**
    let hiddenFieldsDiv = document.createElement('div');
    // Assign class based on the pattern user<N>Username
    hiddenFieldsDiv.className = `user${userIndex}Username`; 
    hiddenFieldsDiv.style.display = 'none'; // Hidden by default

    // Content of the hidden div
    hiddenFieldsDiv.appendChild(document.createElement('hr'));

    let emailLabel = document.createElement('label');
    emailLabel.textContent = 'Email:';
    hiddenFieldsDiv.appendChild(emailLabel);
    let emailInput = document.createElement('input');
    emailInput.type = 'email';
    emailInput.name = `user${userIndex}Email`; // Unique name
    emailInput.value = profile.email || '';
    emailInput.disabled = true;
    emailInput.readOnly = true;
    hiddenFieldsDiv.appendChild(emailInput);

    let ageLabel = document.createElement('label');
    ageLabel.textContent = 'Age:';
    hiddenFieldsDiv.appendChild(ageLabel);
    let ageInput = document.createElement('input');
    ageInput.type = 'number'; 
    ageInput.name = `user${userIndex}Age`; // Unique name
    ageInput.value = profile.age !== undefined ? profile.age : ''; // Handle potential 0 age
    ageInput.disabled = true;
    ageInput.readOnly = true;
    hiddenFieldsDiv.appendChild(ageInput);
    // --- End of hidden div content ---

    // Append hidden div immediately after username input
    profileDiv.appendChild(hiddenFieldsDiv); 

    // Show more / Hide it button
    let button = document.createElement('button');
    button.textContent = 'Show more';
    button.addEventListener('click', toggleDetailsHandler);
    profileDiv.appendChild(button);

    return profileDiv;
}

function toggleDetailsHandler(event) {
    let button = event.target;
    let profileDiv = button.parentElement;
    let unlockRadio = profileDiv.querySelector('input[type="radio"][value="unlock"]');

    // Only proceed if the profile is unlocked
    if (unlockRadio && unlockRadio.checked) {
        
        // Find the hidden div. Since we know the button is the last child,
        // the hidden div should be the element right before the button.
        let hiddenDiv = button.previousElementSibling; 

        // // Alternative way to find hidden div using the class pattern (more robust if structure changes slightly)
        // let usernameInputName = profileDiv.querySelector('input[type="text"]').name; // e.g., user1Username
        // let hiddenDiv = profileDiv.querySelector(`div.${usernameInputName}`);

        if (hiddenDiv) { // Check if found
             if (button.textContent === 'Show more') {
                 hiddenDiv.style.display = 'block';
                 button.textContent = 'Hide it';
             } else {
                 hiddenDiv.style.display = 'none';
                 button.textContent = 'Show more';
             }
        } else {
             console.error("Could not find the hidden details div.");
        }
    }
}

// Execution is triggered by inline script in HTML